# ConsulTrack - Clinical Management System

## Overview

ConsulTrack is a comprehensive multi-role dental platform designed to streamline clinical operations between clinicians and consultants. The system provides role-based access control, patient management, treatment tracking, medical image handling, and financial oversight in a unified interface.

The platform serves two primary user types: clinicians who manage clinics and patients, and consultants who provide specialized services across multiple clinics. Users can switch between roles dynamically when they have multiple permissions, enabling flexible workflow management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with custom clinical color scheme and CSS variables for theming
- **State Management**: TanStack Query for server state management and caching
- **Form Handling**: React Hook Form with Zod for validation
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for full-stack type safety
- **Session Management**: Simple in-memory session store with Bearer token authentication
- **File Handling**: Multer middleware for medical image uploads with validation
- **API Design**: RESTful endpoints with consistent error handling and logging middleware

### Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Schema**: Comprehensive relational design with proper foreign key relationships
- **Key Tables**:
  - Users: Multi-role authentication with specialty and clinic information
  - Consultants: Junction table for consultant-clinic relationships
  - Patients: Complete patient records with treatment and payment tracking
  - Treatment Plans: Structured treatment progression with status tracking
  - Medical Images: File metadata with categorization
  - Payments: Financial transaction records
  - Activities: System audit trail for user actions

### Authentication & Authorization
- **Multi-Role System**: Users can have both clinician and consultant roles simultaneously
- **Role Switching**: Dynamic role changes within active sessions
- **Session-Based**: Bearer token authentication with expiration handling
- **Route Protection**: Middleware-based access control for API endpoints

### File Management
- **Upload Handling**: Secure file upload with type validation (images, PDFs, DICOM files)
- **Storage**: Local filesystem storage with organized directory structure
- **Validation**: File type and size restrictions for security
- **Image Types**: Support for X-rays, photographs, scans, and other medical imagery

### Development Workflow
- **Hot Reload**: Vite development server with HMR for rapid iteration
- **Error Handling**: Runtime error overlays and comprehensive error boundaries
- **Logging**: Structured request logging with performance metrics
- **Build Process**: Separate client and server builds with optimized production output

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity optimized for serverless environments
- **drizzle-orm**: Type-safe ORM for database operations with PostgreSQL support
- **@tanstack/react-query**: Powerful data synchronization and caching for React applications
- **express**: Fast, unopinionated web framework for Node.js backend services

### UI and Styling
- **@radix-ui/**: Complete suite of unstyled, accessible UI primitives for consistent component behavior
- **tailwindcss**: Utility-first CSS framework with custom clinical design system
- **class-variance-authority**: Type-safe CSS class composition for component variants
- **clsx**: Utility for constructing className strings conditionally

### Form and Validation
- **react-hook-form**: Performant forms library with minimal re-renders
- **@hookform/resolvers**: Integration layer for external validation libraries
- **zod**: TypeScript-first schema validation with static type inference
- **drizzle-zod**: Bridge between Drizzle ORM schemas and Zod validation

### File Handling and Utilities
- **multer**: Node.js middleware for handling multipart/form-data file uploads
- **react-dropzone**: Simple React hook for creating HTML5-compliant drag-and-drop zones
- **date-fns**: Modern JavaScript date utility library for date manipulation

### Development Tools
- **vite**: Next-generation frontend build tool with fast HMR and optimized builds
- **tsx**: TypeScript execution environment for Node.js development
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay for better debugging experience